#include <stdlib.h>
#include <stdio.h>
#include <zymkey/zk_app_utils.h>
#include <unistd.h>

int main(int argc, char* argv[])
{
zkCTX ctx;

if(zkOpen(&ctx) <0)
{
	printf("Unable to setup RTC module\n");
	return 0;
}
while(1)
{
	zkLEDOn(ctx);
	sleep(1);
	zkLEDOff(ctx);
}
}
